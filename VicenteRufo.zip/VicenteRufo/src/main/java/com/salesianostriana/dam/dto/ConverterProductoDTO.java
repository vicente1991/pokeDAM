package com.salesianostriana.dam.dto;


import com.salesianostriana.dam.modelo.Producto;
import org.springframework.stereotype.Component;

import javax.persistence.ElementCollection;

@Component

public class ConverterProductoDTO {


    public Producto CreateProductoDTOtoProducto(CreateProductoDTO c){
        return new Producto(
                c.nombre,
                c.descripcion,
                c.pvp
        );
    }

    public GetProductoDTO CreateProductoGetProductoDTO(Producto p){
    GetProductoDTO result = new GetProductoDTO();
        result.setNombre(p.getNombre());
        result.setDescricpion(p.getDescripción());
        result.setCategoria(p.getCategoria());
        result.setPvp(p.getPvp());
        return result;

    }
}







