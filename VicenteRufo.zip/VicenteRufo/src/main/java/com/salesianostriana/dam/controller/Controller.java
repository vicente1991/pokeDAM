package com.salesianostriana.dam.controller;

import com.salesianostriana.dam.dto.ConverterProductoDTO;
import com.salesianostriana.dam.dto.GetProductoDTO;
import com.salesianostriana.dam.modelo.Producto;
import com.salesianostriana.dam.repository.ProductoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/producto")
public class Controller {


    public class PlaylistController {

        private ProductoRepository repository;
        private GetProductoDTO getter;
        private ConverterProductoDTO converter;






        @GetMapping("/")
        public ResponseEntity<List<GetProductotDTO>> findAll(){

            List<Producto> lista = repository.findAll();

            if(lista.isEmpty()){
                return ResponseEntity.notFound().build();

            }else {
                List <GetProductotDTO> resultado = lista.stream()
                        .map(converter::productooGetProductoContDTO)
                        .collect(Collectors.toList());

                return ResponseEntity.ok().body(resultado);
            }
        }




    }




}
