package com.salesianostriana.dam.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Data
@NoArgsConstructor
@AllArgsConstructor

public class CreateProductoDTO {

   public String nombre;
   public String descripcion;
   public double pvp;
}
